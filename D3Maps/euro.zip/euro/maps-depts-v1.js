(function(){
  function addLoadEvent(func) {
    window.onload = function() {
        func();
    };
  }
  // init
  function init(){
    var URL_DATA = '';

    var docDataURL = document.location.toString();
    var searchZoomPattern = 'zoom=';
    var preZoomData;
    var preZoomDataNum = docDataURL.search(searchZoomPattern);
    if (preZoomDataNum > 0) {
      var regex = /zoom=[0-9]+/g;
      var preZoomDataFound = regex.exec(docDataURL);
      preZoomData = preZoomDataFound[0].substr(searchZoomPattern.length);
    }
    //
    var detailData = false;
    var detailDataAbst = false;
    var searchDetailPattern = 'detail=';
    var detailDataNum = docDataURL.search(searchDetailPattern);
    if (detailDataNum > 0) {
      // ?detail=lrm see : data_csv/europeennesColors.csv FEL010
      var regexDtl = /detail=FEL[0-9]+/g;
      var detailDataFound = regexDtl.exec(docDataURL);
      detailData = detailDataFound[0].substr(searchDetailPattern.length);
      // abstentions
      if (detailData == 'FEL000') {
        detailDataAbst = true;
      }
    }
    //
    var searchmapSizePattern = 'mapSize=big';
    var mapSizeDataNum = docDataURL.search(searchmapSizePattern);
    if (mapSizeDataNum > 0) {
        document.getElementById("maps_container").classList.add('big');
    }
    var depart = 0;
    var fin = 5;

    var loader = document.getElementById('spinloader');

    var codeTown = false;
    var foundData, displayedData, dataLevel, maxZoom, codeRegion;

    var map_block = document.getElementById("map_block");
    var width = map_block.clientWidth;
    // allow different size for mobile or desktop
    var height = width *0.8;
    // see in CSS to align @ mq(380px)
    var mobile = false;
    function isMobileDevice() {
      return (typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1);
    }
    if (isMobileDevice() === true) {
      height = width *0.9;
      mobile = true;
    }
    // build blocks and data
    var svgParent = document.querySelector('#map_svg svg');
    var tipsContainer = document.createElement("div");
    svgParent.parentNode.insertBefore(tipsContainer, svgParent);
    tipsContainer.classList.add('tipsContainer');
    var infoText1 = 'Candidat.e qui arrive en tête : ';
    var infoText1b = 'Liste arrivée en tête : ';
    var infoText1c = 'Score : ';
    var infoText1d1 = 'La liste ';
    var infoText1d2 = 'a obtenu ';
    var infoText1d3 = ' des suffrages exprimés.';
    var infoText2 = 'Données non disponibles';
    var infoText3 = 'Cliquez ici pour afficher les infos du département ';
    var infoText4 = ' la légende';
    var loaderText = document.getElementById('spinloaderText');
    loaderText.style.display = 'none';
    var tipsNodal = document.createElement("div");
    svgParent.parentNode.insertBefore(tipsNodal, svgParent);
    if (mobile == true) {
      var map_infos_mobile = document.createElement("div");
      svgParent.parentNode.insertBefore(map_infos_mobile, svgParent);
      map_infos_mobile.classList.add('infos_mobile');
      map_infos_mobile.innerHTML = "Touchez un département puis une commune pour afficher les résultats détaillés.";
    }

    var foundContainer = document.createElement("div");
    svgParent.parentNode.insertBefore(foundContainer, svgParent);
    foundContainer.classList.add('foundContainer');

  //   var cartos = document.createElement("div");
  //   svgParent.parentNode.insertBefore(cartos, svgParent);
  //   cartos.classList.add('cartos');
  //   var cartoBtn = document.createElement('div');
  //   var cartodetails = document.createElement('ul');
  //   cartos.insertAdjacentElement('afterbegin',cartodetails);
  //   cartodetails.setAttribute("id", "cartodetails");

  //   if (detailData !== false) {
  //     // details
  //     var cartodetailsText = document.createElement('div');
  //     cartos.insertAdjacentElement('afterbegin',cartodetailsText);
  //     cartodetailsText.classList.add('cartos-details-list');
  //     cartos.classList.add('cartos-lists');
  //     cartodetails.classList.add('cartos-colors-list');

  //   }else {
  //     // resultats globaux
  //     cartos.insertAdjacentElement('afterbegin',cartoBtn);
  //     cartoBtn.setAttribute("id", "cartoBtn");
  //     cartoBtn.innerHTML = "Afficher" + infoText4;
  //     cartoBtn.classList.add('cartodb-titre');
  //     cartoBtn.addEventListener('click', scrollMe);
  //     cartodetails.classList.add('cartodb-legend','category');
  // }

    var map_bg = document.querySelector("#map_block_bg");
    // map_bg.style.backgroundSize = '100%';
    // if (detailData !== false) {
    //   map_bg.style.backgroundImage = "url('"+URL_DATA+"communes"+detailData+".jpg')";
    // }
    var svg_t = document.getElementById("map_block").querySelector('svg');
    var transform;
    // , layerDpt;

    // function scrollMe() {
    //   var svg_bg = document.querySelector("#map_svg svg");
    //   var searchBlock = document.querySelector(".searchBlock");
    //   if (cartos.className === 'cartos cartos-titre_top'){
    //       cartos.classList.remove('cartos-titre_top');
    //       cartoBtn.innerHTML = "Afficher" + infoText4;
    //       svg_bg.classList.remove('big-svg');
    //       searchBlock.classList.remove('hide');
    //     } else {
    //       cartos.classList.add('cartos-titre_top');
    //       cartoBtn.innerHTML = "Masquer" + infoText4;
    //       svg_bg.classList.add('big-svg');
    //       searchBlock.classList.add('hide');
    //     }
    // }

    function hideTips(){
      tipsContainer.style.display = 'none';
      tipsNodal.classList.remove('tipsNodal');
    }

    function zoomed() {
      transform = d3.zoomTransform(svg_t);
      svg.attr("transform", "translate(" + transform.x + "," + transform.y + ") scale(" + transform.k + ")");
      map_bg_x = precise(transform.x)+'px';
      map_bg_y = precise(transform.y)+'px';
      if (mobile == true) {
        map_bg_y_mob = precise(transform.k)*18;
        map_bg_y = precise(transform.y + map_bg_y_mob )+'px';
      }
      // map_bg.style.backgroundPosition = map_bg_x + ' ' + map_bg_y;
      // map_bg.style.backgroundSize = (transform.k *100) + '%';
      hideShow('hide','show');
    }

    document.getElementById('dezoom').onclick = function() {
      transform.x = 0;
      transform.y = 0;
      transform.k = 1;
      svg.attr("transform", "translate(" + transform.x + "," + transform.y + ") scale(" + transform.k + ")");
      hideShow('show','hide');
      document.getElementById('svg_layer_bg').classList.remove('zoomed');
      topPos = 'top';
      if (mobile == true)
        topPos = '17px';
      map_bg.style.backgroundPosition = 'center ' + topPos;
      map_bg.style.backgroundSize = '100%';
      map_bg.style.opacity = 1;
      foundContainer.style.display = 'none';
    };

    function hideShow(a,b) {
      // 'hide' & 'show'
      document.getElementById('dezoom').classList.remove(a);
      document.getElementById('dezoom').classList.add(b);
    }

    function precise(x) {
      return Number.parseFloat(x).toPrecision(4);
    }

    var projection = d3.geoMercator()
    .center([2.454071, 46.279229])
    .scale(width*3)
    .translate([width / 2, height / 2]);
    path = d3.geoPath().projection(projection);
    svg = d3.select("#map_svg svg")
    .attr("width", "100%").attr("height", "100%")
    .call(d3.zoom().on("zoom", zoomed))
    .append("g");

    function clone(selector) {
      var node = d3.select(selector).node();
      return d3.select(node.parentNode.insertBefore(node.cloneNode(true), node.nextSibling));
    }


    var layerMetroCotes = svg.append("g")
    .attr("id", "svg_layer_metro_cotes");

    // var layerMetro = svg.append("g")
    // .attr("id", "svg_layer_metro");

    var layerBG = svg.append("g")
    .attr("id", "svg_layer_bg");

    var layerOutremer = svg.append("g")
    .attr("id", "svg_layer_outremer");



    // var candidatsColors = [];
    // var codesColors = [];
    // var choixUrl = [];
    var data_root = {};
    data_root.insee = {};
    data_root.winner = {};
    data_root.winnerName = {};
    data_root.communes = {};
    data_root.dep = {};
    data_root.percent = {};



    function loadOutremerMap(json) {
    // function loadFrMap(json) {
      loaderText.innerHTML = 'Chargement de la Fr .';
        layerOutremer.selectAll("path")
        .data(json.features)
        .enter().insert("path")
        .attr("d", path);
      loader.style.display = 'none';
      loaderText.style.display = 'none';
    }

    function loadFrCoteMap(json) {
      loaderText.innerHTML = 'Chargement de la métro .';
        layerMetroCotes.selectAll("path")
        .data(json.features)
        .enter().insert("path")
        // .enter().append("path")
        .attr("d", path);
      loader.style.display = 'none';
      loaderText.style.display = 'none';
    }

    function loadFrMap(json) {
      loaderText.innerHTML = 'Chargement de la Fr .';
        layerMetro.selectAll("path")
        .data(json.geometries)
        .enter().insert("path")
        .attr("d", path);
      loader.style.display = 'none';
      loaderText.style.display = 'none';
    }

    function loadBgMap(json) {
      loaderText.innerHTML = 'Chargement du fond.';
      layerBG.selectAll("path")
        .data(json.features)
        .enter().insert("path")
        // .enter().append("path")
        .attr("d", path);
        // .style("fill", function(d){
        //   // if (detailData == false) {
        //   //   colors = 'rgba(245, 245, 255, 1)';
        //   // }else {
        //   //   // colors = candidatsColors[d.properties.CODE_DEPT];
        //   // }
        //   colors = 'rgba(222, 222, 222, 1)';
        //   return colors;
        // });
        // .on("mouseover", function(d) {
        //     if (mobile === false) {
        //       if (d3.event.layerY > (height - 210)) {
        //         tipsContainer.style.top = (d3.event.layerY - 110) + "px";
        //       }else {
        //         tipsContainer.style.top = (d3.event.layerY + 15) + "px";
        //       }
        //       if (d3.event.layerX > (width - d3.event.layerX)) {
        //         tipsContainer.style.left = (d3.event.layerX - 100) + "px";
        //       }else {
        //         tipsContainer.style.left = (d3.event.layerX + 20) + "px";
        //       }
        //     }
        //     if (mobile == false) {
        //       tipsContainer.innerHTML = infoText3  + '<b>' + d.properties.NOM_DEPT + '</b>';
        //       tipsContainer.style.display = 'block';
        //     }
        // })
        // .on("click", function(d) {
        //   searchedItem = false;
        //   dataLevel = 'department';
        //   codeTown = false;
        //   loader.style.display = 'block';
        //   codeDpt = d.properties.CODE_DEPT;
        //   var loadDpt = URL_DATA + 'data_json/depts/'  + codeDpt + '.json';
        //   // layerDpt = svg.append("g")
        //   layerDpt = svg.insert("g","#svg_layer_bg_strokes")
        //   .attr("id", "svg_layer_dpt_"+codeDpt);
        //   d3.json(loadDpt)
        //   .on("progress", function(d) {
        //     loadingData = Number.parseFloat((d.loaded *100) / d.total).toFixed(1);
        //   }).get(loadSingleDptMap); //loading map departement
        // });
      // var layerBG_clone = clone("#svg_layer_bg").attr("id", "svg_layer_bg_strokes");
      // layerBG_clone.selectAll("path").style("fill",'none');
      loader.style.display = 'none';
      loaderText.style.display = 'none';
    }


    //
    // d3.json('metropole.json')
    // .on("progress", function(d) {
    //   loader.style.display = 'block';
    //   loaderText.style.display = 'block';
    //   loadingMap = Number.parseFloat((d.loaded *100) / d.total).toFixed(1);
    //   loaderText.innerHTML = 'Chargement des informations  des cotes FR. ' + loadingMap + '%';
    //  }).get(loadFrMap);

    //
    d3.json('trait_cote_metropole_2.geojson')
    .on("progress", function(d) {
      loader.style.display = 'block';
      loaderText.style.display = 'block';
      loadingMap = Number.parseFloat((d.loaded *100) / d.total).toFixed(1);
      loaderText.innerHTML = 'Chargement des informations  des datas cotes. ' + loadingMap + '%';
     }).get(loadFrCoteMap);

    //
    d3.json('customtopo.geojson')
    // d3.json('monde-50m-noFr.json')
    .on("progress", function(d) {
      loader.style.display = 'block';
      loaderText.style.display = 'block';
      loadingMap = Number.parseFloat((d.loaded *100) / d.total).toFixed(1);
      loaderText.innerHTML = 'Chargement des informations du fonds. ' + loadingMap + '%';
     }).get(loadBgMap);


    //
    d3.json('metro_dep_971_972_974_976topo.geojson')
    .on("progress", function(d) {
      loader.style.display = 'block';
      loaderText.style.display = 'block';
      loadingMap = Number.parseFloat((d.loaded *100) / d.total).toFixed(1);
      loaderText.innerHTML = 'Chargement des informations des OM. ' + loadingMap + '%';
     }).get(loadOutremerMap);

    // ----- search & autocomplete ---------------------------------------------------------------------------
    var mainBlock = document.getElementById('map-svg-alert');
    var btn = mainBlock.querySelector('input[type=submit]');
    var inptSlug = mainBlock.querySelector('input[name=map-svg-slug]');
    var dptSearch;

    // function getScript(source, callback) {
    //     var script = document.createElement('script');
    //     var prior = document.getElementsByTagName('script')[0];
    //     script.async = 1;
    //     prior.parentNode.insertBefore(script, prior);

    //     script.onload = script.onreadystatechange = function( _, isAbort ) {
    //         if (isAbort || !script.readyState || /loaded|complete/.test(script.readyState)) {
    //             script.onload = script.onreadystatechange = null;
    //             script = undefined;

    //             if (!isAbort) { if (callback) callback(); }
    //         }
    //     };
    //     script.src = source;
    // }

    // function redirectElections(e) {
    //     e.preventDefault();
    //     e.stopPropagation();
    //     var slugValue = mainBlock.querySelector('input[name=map-svg-slug]');
    //     if (slugValue.value.length === 0) {
    //         alert('Vous n\'avez pas sélectionné de Région / Département / Commune.');
    //         return;
    //     }
    //     searchData();
    // }


    // call autocomplete library
    // getScript(window.location.protocol + '//www.francetvinfo.fr/skin/1.2.236/www/js/externe/dist/ftvi-autocomplete_places.min.js', function() {
    //     FtviAutocompletePlaces.init({
    //         inputSelector: '#map-svg-alert input[name=map-svg-commune]',
    //         onSelectCallback: function(data) {
    //             // update hidden input according to selected item
    //             inptSlug.value = data.slug;
    //             foundData = data;
    //             searchData();
    //         },
    //         onEmptyInput: function() {
    //             // flush insee and level
    //             inptSlug.value = '';
    //         }
    //     });
    //     // bind submit
    //     btn.addEventListener('click', redirectElections);
    // });

    // if (preZoomData > 0) {
    //   zoomElections(preZoomData);
    // }




    function hideMe() {
      this.style.display = 'none';
    }

  }
  //
  addLoadEvent(init);
})();
